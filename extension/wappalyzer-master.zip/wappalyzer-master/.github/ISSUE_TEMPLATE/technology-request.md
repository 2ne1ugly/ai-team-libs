---
name: Technology request
about: Propose a technology to be added
title: ''
labels: Technology request
assignees: ''

---

You may request a new technology to be added but chances of having it included are greatly improved if you submit a pull request. Please refer to the [contributing guide](https://github.com/AliasIO/wappalyzer/blob/master/CONTRIBUTING.md).
